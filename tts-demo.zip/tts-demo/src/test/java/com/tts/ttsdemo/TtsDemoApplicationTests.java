package com.tts.ttsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
